#!/usr/bin/env python

if __name__ == "__main__":
    from sacremoses.cli import cli

    cli()
